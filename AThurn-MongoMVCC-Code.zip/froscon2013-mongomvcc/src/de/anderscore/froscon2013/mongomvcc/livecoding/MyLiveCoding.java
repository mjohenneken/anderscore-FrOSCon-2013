package de.anderscore.froscon2013.mongomvcc.livecoding;

import java.net.UnknownHostException;
import java.util.Map;

import de.fhg.igd.mongomvcc.VBranch;
import de.fhg.igd.mongomvcc.VCollection;
import de.fhg.igd.mongomvcc.VDatabase;
import de.fhg.igd.mongomvcc.VFactory;
import de.fhg.igd.mongomvcc.VHistory;
import de.fhg.igd.mongomvcc.impl.MongoDBVFactory;

public class MyLiveCoding {
	
	public static void main(String[] args) throws UnknownHostException {
		VFactory factory = new MongoDBVFactory();
		VDatabase db = factory.createDatabase();
		db.connect("froscon-mvcc");
		
		VBranch master = db.checkout("master");
		
//		VCollection persons = master.getCollection("persons");
		
//		Map<String, Object> myPerson = new HashMap<>();
//		myPerson.put("name", "Mandoline");
//		myPerson.put("age", 10);
//		
//		persons.insert(myPerson);
//		
//		master.commit();
		
//		Map<String, Object> filter = new HashMap<>();
//		filter.put("name", "Mandoline");
//		
//		Map<String, Object> mandoline = persons.findOne(filter);
//		mandoline.put("age", 15);
//		
//		persons.insert(mandoline);
//		master.commit();
		
//		
//		for(Map<String, Object> obj : persons.find()) {
//			System.out.println(obj);
//		}
		
	}
}
