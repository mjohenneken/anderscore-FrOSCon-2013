package de.anderscore.froscon2013.mongomvcc.livecoding;

import java.util.HashMap;
import java.util.Map;

import de.fhg.igd.mongomvcc.VBranch;
import de.fhg.igd.mongomvcc.VCollection;
import de.fhg.igd.mongomvcc.VDatabase;
import de.fhg.igd.mongomvcc.VFactory;
import de.fhg.igd.mongomvcc.impl.MongoDBVFactory;

public class Nicknames {
	public static void main(String[] args) {
		VFactory factory = new MongoDBVFactory();
		VDatabase db = factory.createDatabase();
		db.connect("froscon-mvcc");
		
		
		VBranch master = db.checkout("master");
		
		VBranch nicknamesBranch = db.createBranch("nicknames3", master.getHead());
		
		
		VCollection persons = nicknamesBranch.getCollection("persons");
		
		Map<String, Object> mandiFilter = new HashMap<>();
		mandiFilter.put("name", "Mandoline");

		Map<String, Object> mandoline = persons.findOne(mandiFilter);
		mandoline.put("nickname", "Mandi");
		
		persons.insert(mandoline);
		
		
		
		Map<String, Object> mongoFilter = new HashMap<>();
		mongoFilter.put("name", "Mongo");

		Map<String, Object> mongo = persons.findOne(mongoFilter);
		mongo.put("nickname", "Mo");
		
		persons.insert(mongo);
		
		nicknamesBranch.commit();
		
		
	}
}
