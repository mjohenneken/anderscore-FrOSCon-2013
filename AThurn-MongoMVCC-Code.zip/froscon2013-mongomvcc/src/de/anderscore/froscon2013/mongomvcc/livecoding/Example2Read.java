package de.anderscore.froscon2013.mongomvcc.livecoding;

import java.util.Map;

import de.fhg.igd.mongomvcc.VBranch;
import de.fhg.igd.mongomvcc.VCollection;
import de.fhg.igd.mongomvcc.VConstants;
import de.fhg.igd.mongomvcc.VDatabase;
import de.fhg.igd.mongomvcc.VFactory;
import de.fhg.igd.mongomvcc.impl.MongoDBVFactory;

public class Example2Read {
	public static void main(String[] args) {
		VFactory factory = new MongoDBVFactory();
		VDatabase db = factory.createDatabase();
		db.connect("froscon-mvcc");
		
		VBranch master = db.checkout("nicknames3");

		
		VCollection persons = master.getCollection("persons");
		for(Map<String, Object> obj : persons.find()) {
			System.out.println("Hello, my name is " + obj.get("name") + " im " + obj.get("age") + " years old!");
			if(obj.get("nickname") != null) {
				System.out.println("My nickname is " + obj.get("nickname"));
			}
		}
		
	}
}
