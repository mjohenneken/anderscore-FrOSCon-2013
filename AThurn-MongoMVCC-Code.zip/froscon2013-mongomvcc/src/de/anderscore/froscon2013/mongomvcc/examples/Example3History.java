package de.anderscore.froscon2013.mongomvcc.examples;

import java.util.Map;

import de.fhg.igd.mongomvcc.VBranch;
import de.fhg.igd.mongomvcc.VCollection;
import de.fhg.igd.mongomvcc.VDatabase;
import de.fhg.igd.mongomvcc.VFactory;
import de.fhg.igd.mongomvcc.VHistory;
import de.fhg.igd.mongomvcc.impl.MongoDBVFactory;

public class Example3History {
	public static void main(String[] args) {
		VFactory factory = new MongoDBVFactory();
		VDatabase db = factory.createDatabase();
		db.connect("froscon");
		
		VHistory history = db.getHistory();
		
		VBranch master = db.checkout("myTestBranch2");
		long cid = master.getHead();
		
		while(cid != 0) {
			VBranch commitBranch = db.checkout(cid);
			VCollection persons = commitBranch.getCollection("persons");
			
			System.out.println("Commit " + cid + " -> number of persons " + persons.find().size());
			for(Map<String, Object> obj : persons.find()) {
				System.out.println("Hello, my name is " + obj.get("name") + " im " + obj.get("age") + " years old!");
			}
			System.out.println("----");
			
			cid = history.getParent(cid);
		}
	}
}
