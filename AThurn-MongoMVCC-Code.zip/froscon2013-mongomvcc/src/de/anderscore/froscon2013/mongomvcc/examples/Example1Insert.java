package de.anderscore.froscon2013.mongomvcc.examples;

import java.util.Map;

import de.fhg.igd.mongomvcc.VBranch;
import de.fhg.igd.mongomvcc.VCollection;
import de.fhg.igd.mongomvcc.VConstants;
import de.fhg.igd.mongomvcc.VDatabase;
import de.fhg.igd.mongomvcc.VFactory;
import de.fhg.igd.mongomvcc.impl.MongoDBVFactory;

public class Example1Insert {
	
	public static void main(String[] args) {
		VFactory factory = new MongoDBVFactory();
		VDatabase db = factory.createDatabase();
		db.connect("froscon");
		
		VBranch master = db.checkout(VConstants.MASTER);
		
		//Save objects
		VCollection persons = master.getCollection("persons");
		 
		Map<String, Object> elvis = factory.createDocument();
		elvis.put("name", "Elvis");
		elvis.put("age", 3);
		persons.insert(elvis);
		
		master.commit();
		
		Map<String, Object> eva = factory.createDocument();
		eva.put("name", "Eva");
		eva.put("age", 10);
		persons.insert(eva);
		master.commit();
	}

}
