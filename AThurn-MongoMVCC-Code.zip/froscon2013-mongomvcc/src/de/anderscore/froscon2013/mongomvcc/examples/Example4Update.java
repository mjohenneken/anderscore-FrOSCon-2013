package de.anderscore.froscon2013.mongomvcc.examples;

import java.util.HashMap;
import java.util.Map;

import de.fhg.igd.mongomvcc.VBranch;
import de.fhg.igd.mongomvcc.VCollection;
import de.fhg.igd.mongomvcc.VConstants;
import de.fhg.igd.mongomvcc.VDatabase;
import de.fhg.igd.mongomvcc.VFactory;
import de.fhg.igd.mongomvcc.impl.MongoDBVFactory;

public class Example4Update {
	public static void main(String[] args) {
		VFactory factory = new MongoDBVFactory();
		VDatabase db = factory.createDatabase();
		db.connect("froscon");
		
		VBranch master = db.checkout(VConstants.MASTER);
	
		
		VCollection persons = master.getCollection("persons");
		
		Map<String, Object> filter = new HashMap<>();
		filter.put("name", "Elvis");
		
		Map<String, Object> elvis = persons.findOne(filter);
		elvis.put("name", "Elfis");
		
		persons.insert(elvis);
		master.commit();
	}
}
