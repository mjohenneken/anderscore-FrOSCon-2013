package de.anderscore.froscon2013.mongomvcc.examples;

import de.fhg.igd.mongomvcc.VBranch;
import de.fhg.igd.mongomvcc.VConstants;
import de.fhg.igd.mongomvcc.VDatabase;
import de.fhg.igd.mongomvcc.VFactory;
import de.fhg.igd.mongomvcc.impl.MongoDBVFactory;

public class Example0Connection {
	
	public static void main(String[] args) {
		
		VFactory factory = new MongoDBVFactory();
		VDatabase db = factory.createDatabase();
		db.connect("froscon");
		
		// Checkout the "master" branch
		VBranch master = db.checkout(VConstants.MASTER);
				
		System.out.println("Head is " + master.getHead());
	}
	
	
}
