package de.anderscore.froscon2013.mongomvcc.examples;

public class Example99MergeAndRebase {
	public static void main(String[] args) {
		throw new UnsupportedOperationException("Not implemented yet :(");
	}
}
