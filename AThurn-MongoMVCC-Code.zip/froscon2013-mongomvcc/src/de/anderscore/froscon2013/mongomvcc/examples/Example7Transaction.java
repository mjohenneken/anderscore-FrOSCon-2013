package de.anderscore.froscon2013.mongomvcc.examples;

import java.util.Map;

import de.fhg.igd.mongomvcc.VBranch;
import de.fhg.igd.mongomvcc.VCollection;
import de.fhg.igd.mongomvcc.VDatabase;
import de.fhg.igd.mongomvcc.VFactory;
import de.fhg.igd.mongomvcc.impl.MongoDBVFactory;

public class Example7Transaction {
	public static void main(String[] args) {
		VFactory factory = new MongoDBVFactory();
		VDatabase db = factory.createDatabase();
		db.connect("froscon");
		
		VBranch master = db.checkout("master");
		
		VCollection persons = master.getCollection("persons");
		Map<String, Object> somePerson = persons.find().iterator().next();
		
		persons.delete(somePerson);
		
		master.rollback();
	}
}
